python3 FRONT_END/app.py
